package mybatis.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import mybatis.service.FactoryService;
import mybatis.vo.MemoVO;

public class MemoDAO {
	
	public static List<MemoVO> getList(){
		SqlSession ss = FactoryService.getFactory().openSession();
		
		List<MemoVO> list = ss.selectList("memo.total");
		
		ss.close();
		return list; //이때 list는 절대 null값이 가지 않는다.
	}
	
	public static boolean add(MemoVO vo) {
		SqlSession ss = FactoryService.getFactory().openSession();
		
		int cnt = ss.insert("memo.add", vo);
		
		boolean value = false;
		
		if(cnt > 0) {
			ss.commit();
			value = true;
		}else {
			ss.rollback();
		}
		return value;
	}
	
	public static MemoVO selected_view(String idx){
		SqlSession ss = FactoryService.getFactory().openSession();
		MemoVO vo = ss.selectOne("memo.selected_view", idx);
		return vo;
	}
	
	public static boolean edit(String idx, String writer, String reg_date, String content) {
		Map<String, String> map = new HashMap<String, String>();
		
		int count = 0;
		
		if(idx != null && idx.trim().length() > 0) {
			map.put("idx", idx);
		}
		if(writer != null && writer.trim().length() > 0) {
			map.put("writer", writer);
			count++;
		}
		if(reg_date != null && reg_date.trim().length() > 0) {
			map.put("reg_date", reg_date);
			count++;
		}
		if(content != null && content.trim().length() > 0) {
			map.put("content", content);
			count++;
		}
		
		
		
		//System.out.println(idx+","+writer+","+reg_date+","+content);
		boolean value = false;
		
		if(count > 0) {
			SqlSession ss = FactoryService.getFactory().openSession();
			int cnt = ss.update("memo.edit", map);
			if(cnt > 0) {
				ss.commit();
				value = true;
			}else {
				ss.rollback();
			}
		}
		
		return value;
	}
}
